# notion-date-autofiller
link: https://chrome.google.com/webstore/detail/notion-date-filler/fejlopadadjhidmmmggdkbipcpgedgjp
